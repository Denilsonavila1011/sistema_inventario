<?php
	
	$peticion_ajax=true;
	$code=(isset($_GET['code'])) ? $_GET['code'] : 0;

	/*---------- Incluyendo configuraciones ----------*/
    require_once "../config/APP.php";

	/*---------- Instancia al controlador venta ----------*/
	require_once "../controladores/ventaControlador.php";
	$ins_venta = new ventaControlador();

	$datos_venta=$ins_venta->datos_tabla("Normal","venta INNER JOIN cliente ON venta.cliente_id=cliente.cliente_id INNER JOIN usuario ON venta.usuario_id=usuario.usuario_id INNER JOIN caja ON venta.caja_id=caja.caja_id WHERE (venta_codigo='$code')","*",0);

	if($datos_venta->rowCount()==1){
        
		/*---------- Datos de la venta ----------*/
		$datos_venta=$datos_venta->fetch();

		/*---------- Seleccion de datos de la empresa ----------*/
		$datos_empresa=$ins_venta->datos_tabla("Normal","empresa LIMIT 1","*",0);
		$datos_empresa=$datos_empresa->fetch();


		require "./code128.php";

		$pdf = new PDF_Code128('P','mm',array(57,258));
		$pdf->SetMargins(2,7,2);
        $pdf->AddPage();
        
        $pdf->SetFont('Arial','B',10);
        $pdf->SetTextColor(0,0,0);
        $pdf->MultiCell(0,5,utf8_decode(strtoupper($datos_empresa['empresa_nombre'])),0,'C',false);
        $pdf->SetFont('Arial','',9);
        $pdf->MultiCell(0,5,utf8_decode($datos_empresa['empresa_tipo_documento'].": ".$datos_empresa['empresa_numero_documento']),0,'C',false);
        $pdf->MultiCell(0,5,utf8_decode($datos_empresa['empresa_direccion']),0,'C',false);
        $pdf->MultiCell(0,5,utf8_decode("Teléfono: ".$datos_empresa['empresa_telefono']),0,'C',false);
        $pdf->MultiCell(0,5,utf8_decode("Email: ".$datos_empresa['empresa_email']),0,'C',false);

        $pdf->Ln(1);
        $pdf->Cell(0,5,utf8_decode("-----------------------------------------------"),0,0,'C');
        $pdf->Ln(5);

        $pdf->MultiCell(0,5,utf8_decode("Fecha: ".date("d/m/Y", strtotime($datos_venta['venta_fecha']))." ".$datos_venta['venta_hora']),0,'C',false);
        $pdf->MultiCell(0,5,utf8_decode("Caja Nro: ".$datos_venta['caja_numero']),0,'C',false);
        $pdf->MultiCell(0,5,utf8_decode("Cajero: ".$datos_venta['usuario_nombre']." ".$datos_venta['usuario_apellido']),0,'C',false);
        $pdf->SetFont('Arial','B',10);
        $pdf->MultiCell(0,5,utf8_decode(strtoupper("Ticket Nro: ".$datos_venta['venta_id'])),0,'C',false);
        $pdf->SetFont('Arial','',9);

        $pdf->Ln(1);
        $pdf->Cell(0,5,utf8_decode("-----------------------------------------------"),0,0,'C');
        $pdf->Ln(5);
    
        if($datos_venta['cliente_id']==1){
            $pdf->MultiCell(0,5,utf8_decode("Cliente: N/A"),0,'C',false);
            $pdf->MultiCell(0,5,utf8_decode("Documento: N/A"),0,'C',false);
            $pdf->MultiCell(0,5,utf8_decode("Teléfono: N/A"),0,'C',false);
            $pdf->MultiCell(0,5,utf8_decode("Dirección: N/A"),0,'C',false);
        }else{
            $pdf->MultiCell(0,5,utf8_decode("Cliente: ".$datos_venta['cliente_nombre']." ".$datos_venta['cliente_apellido']),0,'C',false);
            $pdf->MultiCell(0,5,utf8_decode("Documento: ".$datos_venta['cliente_tipo_documento']." ".$datos_venta['cliente_numero_documento']),0,'C',false);
            $pdf->MultiCell(0,5,utf8_decode("Teléfono: ".$datos_venta['cliente_telefono']),0,'C',false);
            $pdf->MultiCell(0,5,utf8_decode("Dirección: ".$datos_venta['cliente_provincia'].", ".$datos_venta['cliente_ciudad'].", ".$datos_venta['cliente_direccion']),0,'C',false);
        }

        $pdf->SetFont('Arial','',8);

        $pdf->Ln(1);
        $pdf->Cell(0,5,utf8_decode("------------------------------------------------------"),0,0,'C');
        $pdf->Ln(3);

        $pdf->Cell(10,5,utf8_decode("Cant."),0,0,'C');
        $pdf->Cell(20,5,utf8_decode("Precio"),0,0,'C');
        $pdf->Cell(27,5,utf8_decode("Total"),0,0,'C');

        $pdf->Ln(3);
        $pdf->Cell(0,5,utf8_decode("------------------------------------------------------"),0,0,'C');
        $pdf->Ln(3);

        /*----------  Seleccionando detalles de la venta  ----------*/
		$venta_detalle=$ins_venta->datos_tabla("Normal","venta_detalle WHERE venta_codigo='".$datos_venta['venta_codigo']."'","*",0);
        $venta_detalle=$venta_detalle->fetchAll();
        
        foreach($venta_detalle as $detalle){
            $pdf->MultiCell(0,4,utf8_decode($detalle['venta_detalle_descripcion']),0,'C',false);
            $pdf->Cell(10,4,utf8_decode($detalle['venta_detalle_cantidad']),0,0,'C');
            $pdf->Cell(20,4,utf8_decode(MONEDA_SIMBOLO.number_format($detalle['venta_detalle_precio_venta'],MONEDA_DECIMALES,MONEDA_SEPARADOR_DECIMAL,MONEDA_SEPARADOR_MILLAR)),0,0,'C');
            $pdf->Cell(27,4,utf8_decode(MONEDA_SIMBOLO.number_format($detalle['venta_detalle_total'],MONEDA_DECIMALES,MONEDA_SEPARADOR_DECIMAL,MONEDA_SEPARADOR_MILLAR)),0,0,'C');
            $pdf->Ln(4);
            if($detalle['venta_detalle_garantia']!="N/A"){
                $pdf->MultiCell(0,4,utf8_decode("Garantía de fábrica: ".$detalle['venta_detalle_garantia']),0,'C',false);
            }
            $pdf->Ln(3);
        }

        $pdf->Cell(0,5,utf8_decode("------------------------------------------------------"),0,0,'C');

        if($datos_empresa['empresa_factura_impuestos']=="Si"){
            $pdf->Ln(5);

            $pdf->Cell(27,5,utf8_decode("SUBTOTAL"),0,0,'C');
            $pdf->Cell(30,5,utf8_decode("+ ".MONEDA_SIMBOLO.number_format($datos_venta['venta_subtotal'],MONEDA_DECIMALES,MONEDA_SEPARADOR_DECIMAL,MONEDA_SEPARADOR_MILLAR)),0,0,'C');

            $pdf->Ln(5);

            $pdf->Cell(27,5,utf8_decode($datos_venta['venta_impuesto_nombre']." (".$datos_venta['venta_impuesto_porcentaje']."%)"),0,0,'C');
            $pdf->Cell(30,5,utf8_decode("+ ".MONEDA_SIMBOLO.number_format($datos_venta['venta_impuestos'],MONEDA_DECIMALES,MONEDA_SEPARADOR_DECIMAL,MONEDA_SEPARADOR_MILLAR)),0,0,'C');

            $pdf->Ln(5);

            $pdf->Cell(0,5,utf8_decode("------------------------------------------------------"),0,0,'C');
        }

        $pdf->Ln(5);

        $pdf->Cell(27,5,utf8_decode("TOTAL A PAGAR"),0,0,'C');
        $pdf->Cell(30,5,utf8_decode(MONEDA_SIMBOLO.number_format($datos_venta['venta_total_final'],MONEDA_DECIMALES,MONEDA_SEPARADOR_DECIMAL,MONEDA_SEPARADOR_MILLAR).' '.MONEDA_NOMBRE),0,0,'C');

        $pdf->Ln(5);
        
        $pdf->Cell(27,5,utf8_decode("TOTAL PAGADO"),0,0,'C');
        $pdf->Cell(30,5,utf8_decode(MONEDA_SIMBOLO.number_format($datos_venta['venta_pagado'],MONEDA_DECIMALES,MONEDA_SEPARADOR_DECIMAL,MONEDA_SEPARADOR_MILLAR).' '.MONEDA_NOMBRE),0,0,'C');

        $pdf->Ln(5);

        $pdf->Cell(27,5,utf8_decode("CAMBIO"),0,0,'C');
        $pdf->Cell(30,5,utf8_decode(MONEDA_SIMBOLO.number_format($datos_venta['venta_cambio'],MONEDA_DECIMALES,MONEDA_SEPARADOR_DECIMAL,MONEDA_SEPARADOR_MILLAR).' '.MONEDA_NOMBRE),0,0,'C');

        $pdf->Ln(10);

        $pdf->SetFont('Arial','',9);

        $pdf->MultiCell(0,5,utf8_decode("*** Precios de productos incluyen impuestos. Para poder realizar un reclamo o devolución debe de presentar este ticket ***"),0,'C',false);

        $pdf->SetFont('Arial','B',9);
        $pdf->Cell(0,7,utf8_decode("Gracias por su compra"),'',0,'C');

        $pdf->Ln(9);

        $pdf->Code128(4,$pdf->GetY(),$datos_venta['venta_codigo'],50,20);
        $pdf->SetXY(0,$pdf->GetY()+21);
        $pdf->SetFont('Arial','',10);
        $pdf->MultiCell(0,5,utf8_decode($datos_venta['venta_codigo']),0,'C',false);
        
		$pdf->Output("I","Ticket_Nro".$datos_venta['venta_id'].".pdf",true);

	}else{
?>
<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
	<title><?php echo COMPANY; ?></title>
	<?php include '../vistas/inc/Head.php'; ?>
</head>
<body>
	<div class="full-box container-404">
		<div>
			<p class="text-center"><i class="fas fa-rocket fa-10x"></i></p>
			<h1 class="text-center">¡Ocurrió un error!</h1>
			<p class="lead text-center">No hemos encontrado datos de la venta</p>
		</div>
	</div>
	<?php include '../vistas/inc/Script.php'; ?>
</body>
</html>
<?php } ?>