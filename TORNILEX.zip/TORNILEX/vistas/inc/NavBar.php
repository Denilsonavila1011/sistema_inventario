<nav class="full-box navbar-info">
    <a href="#" class="float-left show-nav-lateral">
        <i class="fas fa-bars"></i>
    </a>
    <a href="<?php echo SERVERURL."user-update/".$lc->encryption($_SESSION['id_svi'])."/"; ?>">
        <i class="fas fa-user-cog"></i>
    </a>
    <a href="#" class="btn-exit-system">
        <i class="fas fa-power-off"></i>
    </a>
</nav>